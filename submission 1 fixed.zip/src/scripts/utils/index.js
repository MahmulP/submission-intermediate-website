export function showFormattedDate(date, locale = 'en-US', options = {}) {
  return new Date(date).toLocaleDateString(locale, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    ...options,
  });
}

export function sleep(time = 1000) {
  return new Promise((resolve) => setTimeout(resolve, time));
}

export function getLoadingTemplate(message = "Loading...") {
  return `
    <div class="loading-indicator" aria-live="polite" aria-busy="true">
      <div class="spinner"></div>
      <span>${message}</span>
    </div>
  `;
}

export function renderNav() {
  const navList = document.getElementById('nav-list');
  const isLoggedIn = !!localStorage.getItem('token');

  navList.innerHTML = `
    <li><a href="#/">Beranda</a></li>
    ${isLoggedIn
      ? `
        <li><a href="#/add-story">Add Story</a></li>
        <li><a href="#" id="logout-link">Logout</a></li>
      `
      : `<li><a href="#/login">Login</a></li>
         <li><a href="#/register">Register</a></li>`
    }
  `;

  if (isLoggedIn) {
    const logoutLink = document.getElementById('logout-link');
    if (logoutLink) {
      logoutLink.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('token');
        window.location.hash = '/login';
        renderNav();
      });
    }
  }
}